#include "pch.h"
#include "EndScene.h"


EndScene::EndScene()
{

}

EndScene::~EndScene()
{

}

void EndScene::Init()
{

}
void EndScene::Control()
{

}

void EndScene::Update(float)
{

}

void EndScene::Render(Gdiplus::Graphics* MemG)
{

}