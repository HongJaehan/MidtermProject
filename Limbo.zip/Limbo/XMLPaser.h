#pragma once
class XMLPaser
{
public:
	XMLPaser();
	~XMLPaser();

private:

};

