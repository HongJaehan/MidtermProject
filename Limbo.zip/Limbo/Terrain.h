#pragma once
#include "object.h"
class Terrain :public Object 
{

};

