#include "pch.h"
#include "XMLPaser.h"

XMLPaser::XMLPaser()
{

}

XMLPaser::~XMLPaser()
{

}
