#include "pch.h"
#include "Scene.h"

Scene::Scene()
{

}

Scene::~Scene()
{

}