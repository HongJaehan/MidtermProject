#include "pch.h"
#include "object.h"

Object::Object()
{

}

Object::~Object()
{

}